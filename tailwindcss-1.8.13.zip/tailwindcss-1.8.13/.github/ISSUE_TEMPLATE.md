<!--

👋 Hey, thanks for taking an interest in Tailwind!

We don't accept issues that don't use our issue template.

Please use this link to create your issue:

https://github.com/tailwindcss/tailwindcss/issues/new/choose

Issues that don't follow our issue template will be closed, as it's just impossible to triage and resolve issues without some sort of system with the small team we have.

-->
